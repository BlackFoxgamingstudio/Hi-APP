<?php
$con = mysql_connect("localhost:3306","rocklee45","N@ruto45");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
  
            $techid = $_POST['techid'];
          
$topicdesc = mysql_real_escape_string($_POST['topicdesc']);  

		

$sql = "UPDATE topic SET topicdesc = '$topicdesc' WHERE techid = '$techid'";
mysql_select_db("jtabletestdb2", $con);
$retval = mysql_query($sql,$con);
              
if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }
  
  echo "1 Topic record uppyed";
 	
 	
 echo "<a href='http://www.powersbroznetwork.com/jTable-PHP-Samples/Codes/Blackfox.php'>Link</a>";	
mysql_close($con)

?>


