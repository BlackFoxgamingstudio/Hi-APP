<?php
class Connect{
	public $db = "websitesaya";
	
	public function connect(){
		return mysqli_connect('localhost', 'root', 'abcd.123', $this->db);
	}
}
?>