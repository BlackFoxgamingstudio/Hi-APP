<head>
<style>
table {
    width: 100%;
    border-collapse: collapse;
}

table, td, th {
    border: 1px solid black;
    padding: 5px;
}

th {text-align: left;}
</style>
</head>
<body>

<?php
$q = intval($_GET['q']);

$con = mysql_connect("localhost:3306","rocklee45","N@ruto45","jtabletestdb2");

if (!$con) {
    die('Could not connect: ' . mysqli_error($con));
}
mysql_select_db("jtabletestdb2", $con);

$sql="SELECT * FROM Tech WHERE techid = '".$q."'";
$result = mysql_query($sql, $con);

echo "<table>
<tr>
<th>TechName</th>
<th>Description</th>
</tr>";
while($row = mysql_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['TechName'] . "</td>";
    echo "<td>" . $row['Description'] . "</td>";
    echo "</tr>";
}
echo "</table>";
mysql_close($con);
?>
</body>

 