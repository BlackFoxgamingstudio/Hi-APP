  
	    
	      <div id="wrapper2" class="active2">  
   
    <div id="sidebar-wrapper">
        <ul id="sidebar_menu" class="sidebar-nav">
           <li class="sidebar-brand"><a id="menu-toggle" href="#">Subjects<span id="main_icon" class="glyphicon glyphicon-align-justify"></span></a></li>
        </ul>
        <ul class="sidebar-nav" id="sidebar">
          <li><a>Subject1.Name<span class="sub_icon glyphicon glyphicon-link"></span></a></li>
          <li><a>Subject2.Name<span class="sub_icon glyphicon glyphicon-link"></span></a></li>
                <li><a>Subject3.Name<span class="sub_icon glyphicon glyphicon-link"></span></a></li>
          <li><a>Subject4.Name<span class="sub_icon glyphicon glyphicon-link"></span></a></li>
          <li><a>Subject5.Name<span class="sub_icon glyphicon glyphicon-link"></span></a></li>
        </ul>
               
      </div>
          
      <!-- Page content -->
      <div id="page-content-wrapper">
        <!-- Keep all page content within the page-content inset div! -->
        <div class="page-content inset">
            <div class="row">
              <div class="col-md-12">
              <p class="well lead">Subject1.Name</p>
              <div class="container">
               <!--HTML Posted here Buy Php jquery Load page method--> 
               
               <h1>Topic1.Name - (Topic1.HtmLTemplate1.Name) Nindo Demo Lvl 1</h1>

<p><b>(Topic1.HtmLTemplate1.Description)</b>  Template1 is Made to guide the Users Creation Of His/her own Ninja way...<i>"To be a ninja is to Endure"</i>-Naruto45 </p>

<p><b>(Topic1.HtmLTemplate1.Level Discription)</b> Level one(begenners) will cover the fundementals throw a Project serving as your first exposere to the Topic as a Proof of concept (POC). This Level One POC will be your refrance point to help you gain begenner <b>experince Points</b> buy doing research and adding to the List of <b>Projects</b> below OR Adding to the List of <b>Resources</b> Bellow through <b>Study</b>. Finnaly, your goal is to </b>create your own PoCs</b> to prove your mastery of the Begenner level. Store Your PoC in the Space Bellow.</p>

<p><b>(Topic1.HtmLTemplate1.Goal)</b> The level one Goal (begenner) is to get you an understanding of the basic concepts allowing you to learn by building and understand the order of operations. Next you will need to learn the Domians of the tech. Finally you will understand how to connect data between domains to finsh any begenner level project to level up to  someday become a hacker level Blackfoxer.</p>

<ol>
	<li><i>link</i> <b>(Topic1.HtmLTemplate1.Project Link1)</b></li>
	<li><i>link</i> <b>(Topic1.HtmLTemplate1.Project Link2)</b> </li>
	<li><i>link</i> <b>(Topic1.HtmLTemplate1.Project Link3)</b> </li>
</ol>


<p>you will gain more expeirnce points buy studying and take detailed notes on the above project. Then trying to create your own PoCs based of your notes! </p>

<ol>
	<li><i>link</i> <b>(Topic1.HtmLTemplate1.Resource Link1)</b></li>
	<li><i>link</i> <b>(Topic1.HtmLTemplate1.Resource Link2)</b> </li>
	<li><i>link</i> <b>(Topic1.HtmLTemplate1.Resource Link3)</b> </li>
</ol>


<p>THe Key to progress is to take clean notes and capturing Examples, Explaination and study guild orgained AS YOUR OWN STUDYGUIDE. YOu create your resource <b>design</b> obtimizing it for the problems you need to solove in your study. <u>this is the key to success in life</u>. Organize your resource in one zip file include 1 excel workbook, 1 powerpointside, 1 Onenote tab, one word doc readmefile and one PDF onepage studyguide. <b>(here is a link to the templated examples for each)</b>  </p>

<ol>
	<li><i>link</i> <b>(Topic1.HtmLTemplate1.PoC Link1)</b></li>
	<li><i>link</i> <b>(Topic1.HtmLTemplate1.PoC Link2)</b> </li>
	<li><i>link</i> <b>(Topic1.HtmLTemplate1.PoC Link3)</b> </li>
</ol>


<p>you will build a resume with PoC to Prove you know the infomation and have the Skills need work as a developer.</p>


               <!--Replace with jquery load div>
                </div> <!-- fim div da esquerda -->
            </div>
              <p class="well lead">An Experiment using the sidebar (<a href="https://animeshmanglik.name">animeshmanglik.name</a>)</p> 
            </div>
          </div>
        </div>
    </div>
      
</div>
	   <script>




</script>

 